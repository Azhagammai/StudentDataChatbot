document.addEventListener('DOMContentLoaded', function() {
    // Initialize chart if present on page
    initializeChart();
    
    // Add Student Modal
    const addStudentBtn = document.getElementById('add-student-btn');
    const addStudentModal = document.getElementById('add-student-modal');
    const closeAddStudentModal = document.getElementById('close-add-student-modal');
    const addStudentForm = document.getElementById('add-student-form');
    
    if (addStudentBtn) {
        addStudentBtn.addEventListener('click', function() {
            addStudentModal.style.display = 'flex';
        });
    }
    
    if (closeAddStudentModal) {
        closeAddStudentModal.addEventListener('click', function() {
            addStudentModal.style.display = 'none';
        });
    }
    
    // Close modal if clicked outside
    window.addEventListener('click', function(event) {
        if (event.target === addStudentModal) {
            addStudentModal.style.display = 'none';
        }
        
        if (event.target === uploadDocModal) {
            uploadDocModal.style.display = 'none';
        }
    });
    
    // Upload Document Modal
    const uploadDocBtn = document.getElementById('upload-doc-btn');
    const uploadDocModal = document.getElementById('upload-doc-modal');
    const closeUploadDocModal = document.getElementById('close-upload-doc-modal');
    const uploadDocForm = document.getElementById('upload-doc-form');
    
    if (uploadDocBtn) {
        uploadDocBtn.addEventListener('click', function() {
            uploadDocModal.style.display = 'flex';
        });
    }
    
    if (closeUploadDocModal) {
        closeUploadDocModal.addEventListener('click', function() {
            uploadDocModal.style.display = 'none';
        });
    }
    
    // Handle Add Student Form Submission
    if (addStudentForm) {
        addStudentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(addStudentForm);
            
            fetch('/admin/add_student', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    showMessage('Student added successfully!', 'success');
                    
                    // Close modal
                    addStudentModal.style.display = 'none';
                    
                    // Reset form
                    addStudentForm.reset();
                    
                    // Refresh page after a delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    // Show error message
                    showMessage('Error: ' + data.error, 'error');
                }
            })
            .catch(error => {
                showMessage('An error occurred. Please try again.', 'error');
                console.error('Error:', error);
            });
        });
    }
    
    // Handle Upload Document Form Submission
    if (uploadDocForm) {
        uploadDocForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(uploadDocForm);
            
            fetch('/admin/upload_document', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Show success message
                    showMessage('Document uploaded successfully!', 'success');
                    
                    // Close modal
                    uploadDocModal.style.display = 'none';
                    
                    // Reset form
                    uploadDocForm.reset();
                    
                    // Refresh page after a delay
                    setTimeout(() => {
                        window.location.reload();
                    }, 1500);
                } else {
                    // Show error message
                    showMessage('Error: ' + data.error, 'error');
                }
            })
            .catch(error => {
                showMessage('An error occurred. Please try again.', 'error');
                console.error('Error:', error);
            });
        });
    }
    
    // Function to show message
    function showMessage(message, type) {
        const messageContainer = document.createElement('div');
        messageContainer.className = `message-container ${type}`;
        messageContainer.textContent = message;
        
        document.body.appendChild(messageContainer);
        
        // Remove message after 3 seconds
        setTimeout(() => {
            messageContainer.remove();
        }, 3000);
    }
    
    // Function to initialize chart
    function initializeChart() {
        const chatStatsCanvas = document.getElementById('chat-stats-chart');
        
        if (chatStatsCanvas) {
            const chatDates = JSON.parse(chatStatsCanvas.getAttribute('data-dates') || '[]');
            const chatCounts = JSON.parse(chatStatsCanvas.getAttribute('data-counts') || '[]');
            
            const ctx = chatStatsCanvas.getContext('2d');
            
            // Create chart
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: chatDates,
                    datasets: [{
                        label: 'Chat Messages',
                        data: chatCounts,
                        backgroundColor: 'rgba(255, 140, 0, 0.2)',
                        borderColor: 'rgba(255, 140, 0, 1)',
                        borderWidth: 2,
                        pointBackgroundColor: 'rgba(255, 140, 0, 1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                precision: 0
                            }
                        }
                    },
                    plugins: {
                        title: {
                            display: true,
                            text: 'Chat Activity (Last 7 Days)',
                            font: {
                                size: 16
                            }
                        },
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
    }
});
