import pandas as pd
import re
import fitz  # PyMuPDF

def extract_pdf_text(pdf_path):
    """Extract text from a PDF file using PyMuPDF with improved extraction."""
    import logging
    logger = logging.getLogger(__name__)
    
    try:
        logger.info(f"Attempting to extract text from PDF: {pdf_path}")
        text = ""
        
        # Check if file exists
        import os
        if not os.path.exists(pdf_path):
            logger.error(f"PDF file does not exist: {pdf_path}")
            # Try alternative paths
            alt_paths = [
                'data/code_of_conduct.pdf',
                'attached_assets/code_of_conduct.pdf',
                # Try to find any PDF in these directories
                *[f'data/{f}' for f in os.listdir('data') if f.endswith('.pdf')],
                *[f'attached_assets/{f}' for f in os.listdir('attached_assets') if f.endswith('.pdf')],
                *[f'uploads/{f}' for f in os.listdir('uploads') if os.path.exists('uploads') and f.endswith('.pdf')]
            ]
            
            for alt_path in alt_paths:
                if os.path.exists(alt_path):
                    logger.info(f"Found alternative PDF at: {alt_path}")
                    pdf_path = alt_path
                    break
            else:
                return "PDF file not available. Please contact administrator."
        
        # Open and extract the PDF
        logger.info(f"Opening PDF file: {pdf_path}")
        doc = fitz.open(pdf_path)
        logger.info(f"PDF opened successfully with {len(doc)} pages")
        
        # Extract text with better formatting
        sections = []
        current_section = ""
        current_heading = "Introduction"  # Default heading
        
        for i, page in enumerate(doc):
            logger.info(f"Extracting text from page {i+1}")
            try:
                # Get text with more structure preservation
                page_dict = page.get_text("dict")
                page_text = ""
                
                # Process blocks to identify headings and paragraphs
                for block in page_dict["blocks"]:
                    if "lines" in block:
                        for line in block["lines"]:
                            line_text = ""
                            for span in line["spans"]:
                                # Check if it's potentially a heading (bold or larger font)
                                is_heading = span["font"].lower().find("bold") >= 0 or span["size"] > 12
                                text_content = span["text"].strip()
                                
                                if is_heading and len(text_content) < 100 and text_content.upper() == text_content:
                                    # This is likely a heading
                                    if current_section:
                                        # Store the previous section
                                        sections.append((current_heading, current_section))
                                        current_section = ""
                                    current_heading = text_content
                                
                                line_text += text_content + " "
                            
                            page_text += line_text.strip() + "\n"
                            current_section += line_text.strip() + "\n"
                
                # If we couldn't extract structured text, fallback to regular text
                if not page_text:
                    page_text = page.get_text()
                    current_section += page_text
                
                text += page_text
                
            except Exception as page_error:
                logger.error(f"Error extracting text from page {i+1}: {str(page_error)}")
                # Try alternative method
                try:
                    page_text = page.getText()
                    text += page_text
                    current_section += page_text
                except:
                    error_msg = f"[Error extracting page {i+1}]"
                    text += error_msg
                    current_section += error_msg
        
        # Store the last section
        if current_section:
            sections.append((current_heading, current_section))
        
        # Store the sections for later retrieval
        import json
        try:
            with open(f"{os.path.splitext(pdf_path)[0]}_sections.json", "w") as f:
                json.dump(sections, f)
            logger.info(f"Saved {len(sections)} extracted sections from {pdf_path}")
        except Exception as save_error:
            logger.error(f"Error saving PDF sections: {str(save_error)}")
        
        logger.info(f"Successfully extracted {len(text)} characters from PDF")
        return text
    except Exception as e:
        logger.error(f"Error extracting PDF text: {str(e)}")
        return "Error extracting PDF text. Please try again later or contact administrator."

def search_pdf_content(query, pdf_text=None, pdf_path=None):
    """Search for content in PDF based on query."""
    import logging
    import re
    import os
    logger = logging.getLogger(__name__)
    
    try:
        if not pdf_text and pdf_path:
            # Try to load from cached sections first
            sections_path = f"{os.path.splitext(pdf_path)[0]}_sections.json"
            if os.path.exists(sections_path):
                import json
                try:
                    with open(sections_path, "r") as f:
                        sections = json.load(f)
                    
                    # Search in sections
                    relevant_sections = []
                    for heading, content in sections:
                        # Check if query terms match the heading or content
                        if any(term.lower() in heading.lower() or term.lower() in content.lower() 
                               for term in query.lower().split()):
                            relevant_sections.append((heading, content))
                    
                    if relevant_sections:
                        logger.info(f"Found {len(relevant_sections)} relevant sections for query: {query}")
                        result = "\n\n".join([f"## {heading}\n{content}" for heading, content in relevant_sections])
                        return result
                except Exception as json_error:
                    logger.error(f"Error loading PDF sections: {str(json_error)}")
            
            # Fallback to full text extraction
            pdf_text = extract_pdf_text(pdf_path)
        
        if not pdf_text:
            return "No PDF content available to search"
        
        # Search for relevant paragraphs
        query_terms = query.lower().split()
        paragraphs = re.split(r'\n\s*\n', pdf_text)
        
        relevant_paragraphs = []
        for paragraph in paragraphs:
            # Skip very short paragraphs
            if len(paragraph.strip()) < 20:
                continue
                
            # Check if query terms match
            if any(term.lower() in paragraph.lower() for term in query_terms):
                relevant_paragraphs.append(paragraph.strip())
        
        if relevant_paragraphs:
            logger.info(f"Found {len(relevant_paragraphs)} relevant paragraphs for query: {query}")
            return "\n\n".join(relevant_paragraphs)
        else:
            # Try a more lenient search
            for paragraph in paragraphs:
                # Count how many terms match
                matches = sum(1 for term in query_terms if term.lower() in paragraph.lower())
                if matches > 0:
                    relevant_paragraphs.append(paragraph.strip())
                    
                    # Limit to top 3 paragraphs
                    if len(relevant_paragraphs) >= 3:
                        break
            
            if relevant_paragraphs:
                logger.info(f"Found {len(relevant_paragraphs)} loosely relevant paragraphs for query: {query}")
                return "\n\n".join(relevant_paragraphs)
            else:
                return f"No specific information found about '{query}' in the document."
                
    except Exception as e:
        logger.error(f"Error searching PDF content: {str(e)}")
        return f"Error searching for '{query}' in PDF content."

def validate_student(serial_no, roll_no):
    """Validate student credentials against the CSV file."""
    import logging
    logger = logging.getLogger(__name__)
    
    try:
        logger.info(f"Validating student with serial_no={serial_no}, roll_no={roll_no}")
        
        # Try to load from different possible CSV locations
        try:
            logger.info("Attempting to load from data/students.csv")
            df = pd.read_csv('data/students.csv')
            logger.info(f"Successfully loaded data/students.csv with {len(df)} records")
        except Exception as csv_error:
            logger.error(f"Error loading data/students.csv: {str(csv_error)}")
            # Fallback to updated_students_data.csv
            try:
                logger.info("Attempting to load from data/updated_students_data.csv")
                df = pd.read_csv('data/updated_students_data.csv')
                logger.info(f"Successfully loaded data/updated_students_data.csv with {len(df)} records")
            except Exception as update_error:
                logger.error(f"Error loading data/updated_students_data.csv: {str(update_error)}")
                # Fallback to the provided CSV in attached_assets
                logger.info("Attempting to load from attached_assets/students.csv")
                df = pd.read_csv('attached_assets/students.csv')
                logger.info(f"Successfully loaded attached_assets/students.csv with {len(df)} records")
        
        # Convert to string for comparison (in case they're stored differently)
        serial_no = str(serial_no)
        roll_no = str(roll_no)
        
        logger.info(f"Looking for student with serial_no={serial_no}, roll_no={roll_no}")
        
        # Check if the student exists
        student = df[(df['serial_no'].astype(str) == serial_no) & 
                     (df['roll_no'].astype(str) == roll_no)]
        
        if not student.empty:
            # Return student information as a dictionary
            logger.info(f"Student validated successfully: {student.iloc[0]['name']}")
            return student.iloc[0].to_dict()
        else:
            logger.warning(f"No student found with serial_no={serial_no}, roll_no={roll_no}")
            return None
    except Exception as e:
        logger.error(f"Error validating student: {str(e)}")
        return None

def get_student_data(serial_no, roll_no):
    """Get student data from CSV file."""
    import logging
    logger = logging.getLogger(__name__)
    
    try:
        logger.info(f"Attempting to get data for student with serial_no={serial_no}, roll_no={roll_no}")
        
        # Try to load from different CSV files in order of preference
        csv_files = [
            'data/students.csv',
            'data/updated_students_data.csv',
            'attached_assets/students.csv',
            'attached_assets/updated_students_data.csv',
            'students.csv'
        ]
        
        df = None
        for csv_file in csv_files:
            try:
                import os
                if os.path.exists(csv_file):
                    logger.info(f"Attempting to load from {csv_file}")
                    df = pd.read_csv(csv_file)
                    logger.info(f"Successfully loaded {csv_file} with {len(df)} records")
                    break
            except Exception as err:
                logger.error(f"Error loading {csv_file}: {str(err)}")
        
        if df is None:
            logger.error("Could not load any student data files")
            return {}
        
        # Convert to string for comparison
        serial_no = str(serial_no)
        roll_no = str(roll_no)
        
        logger.info(f"Looking for student with serial_no={serial_no}, roll_no={roll_no}")
        
        # Find the student
        student = df[(df['serial_no'].astype(str) == serial_no) & 
                     (df['roll_no'].astype(str) == roll_no)]
        
        if not student.empty:
            logger.info(f"Found student: {student.iloc[0]['name']}")
            student_raw_data = student.iloc[0].to_dict()
            # Log keys to help with debugging
            logger.info(f"Student data keys: {list(student_raw_data.keys())}")
            
            # Format the student data with better labels and organization
            student_data = {}
            
            # Basic information with better labeling
            field_mapping = {
                'serial_no': 'Serial Number',
                'roll_no': 'Roll Number',
                'name': 'Student Name',
                'major': 'Major',
                'current_gpa': 'Current GPA',
                'date_of_birth': 'Date of Birth',
                'gender': 'Gender',
                'hobbies': 'Hobbies',
                'phone_number': 'Phone Number'
            }
            
            # Copy all fields with better labels
            for field, label in field_mapping.items():
                if field in student_raw_data and pd.notna(student_raw_data[field]):
                    student_data[label] = student_raw_data[field]
                    # Keep original field name for compatibility
                    student_data[field] = student_raw_data[field]
            
            # Add parent information
            parent_fields = {
                'father_name': 'Father\'s Name', 
                'mother_name': 'Mother\'s Name'
            }
            
            has_parent_info = False
            for field, label in parent_fields.items():
                if field in student_raw_data and pd.notna(student_raw_data[field]):
                    student_data[label] = student_raw_data[field]
                    student_data[field] = student_raw_data[field]
                    has_parent_info = True
            
            # If we found parent info, log it
            if has_parent_info:
                logger.info(f"Found parent information for student {student_raw_data['name']}")
            
            # Add address information
            address_fields = {
                'street': 'Street Address',
                'city': 'City',
                'state': 'State',
                'pin_code': 'PIN Code'
            }
            
            address_parts = []
            for field, label in address_fields.items():
                if field in student_raw_data and pd.notna(student_raw_data[field]):
                    value = str(student_raw_data[field])
                    student_data[label] = value
                    student_data[field] = value
                    address_parts.append(value)
            
            # Create full address if we have components
            if address_parts:
                student_data['Full Address'] = ', '.join(address_parts)
                logger.info(f"Created full address for student {student_raw_data['name']}")
            
            # Add attendance information
            attendance_fields = {
                'total_days': 'Total Days',
                'days_present': 'Days Present',
                'days_absent': 'Days Absent'
            }
            
            for field, label in attendance_fields.items():
                if field in student_raw_data and pd.notna(student_raw_data[field]):
                    # Convert to appropriate numeric type
                    try:
                        value = float(student_raw_data[field])
                        if value.is_integer():
                            value = int(value)
                        student_data[label] = value
                        student_data[field] = value
                    except:
                        student_data[label] = student_raw_data[field]
                        student_data[field] = student_raw_data[field]
            
            # Calculate attendance percentage if we have the necessary data
            if 'Total Days' in student_data and 'Days Present' in student_data:
                try:
                    attendance = (float(student_data['Days Present']) / float(student_data['Total Days'])) * 100
                    student_data['Attendance Percentage'] = f"{attendance:.2f}%"
                    logger.info(f"Calculated attendance percentage: {student_data['Attendance Percentage']}")
                except Exception as e:
                    logger.error(f"Error calculating attendance percentage: {str(e)}")
            
            # Add courses information
            if 'courses' in student_raw_data and pd.notna(student_raw_data['courses']):
                student_data['Courses'] = student_raw_data['courses']
                student_data['courses'] = student_raw_data['courses']
                logger.info(f"Found courses for student: {student_data['Courses']}")
            
            # Add semester information
            for i in range(1, 7):
                sem_key = f"Semester {i}"
                if sem_key in student_raw_data and pd.notna(student_raw_data[sem_key]):
                    try:
                        value = float(student_raw_data[sem_key])
                        student_data[sem_key] = value
                        student_data[f"{sem_key} GPA"] = value
                    except:
                        student_data[sem_key] = student_raw_data[sem_key]
                        student_data[f"{sem_key} GPA"] = student_raw_data[sem_key]
            
            logger.info(f"Returning {len(student_data)} formatted data fields for student")
            return student_data
        else:
            logger.warning(f"No student found with serial_no={serial_no}, roll_no={roll_no}")
            return {}
    except Exception as e:
        logger.error(f"Error getting student data: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {}

def format_gemini_response(response):
    """Format the response from Gemini for better readability.
    
    Handles both direct string responses and Gemini API response objects.
    """
    # Check if the response is an object (old version) or a string (new version)
    if hasattr(response, 'text'):
        # Old version: response is a Gemini API response object
        response_text = response.text
    else:
        # New version: response is already a string
        response_text = response
    
    # Remove any system instructions that might have been included
    response_text = re.sub(r'As an AI assistant.*?\.', '', response_text, flags=re.DOTALL)
    response_text = re.sub(r'You are a helpful.*?\.', '', response_text, flags=re.DOTALL)
    
    # Clean up extra whitespace
    response_text = re.sub(r'\n{3,}', '\n\n', response_text)
    response_text = response_text.strip()
    
    return response_text

def calculate_attendance_percentage(days_present, total_days):
    """Calculate attendance percentage."""
    try:
        if total_days > 0:
            return (days_present / total_days) * 100
        return 0
    except:
        return 0

def get_chat_statistics():
    """Get chat statistics for admin dashboard."""
    import sqlite3
    from datetime import datetime, timedelta
    
    conn = sqlite3.connect('student_chatbot.db')
    cursor = conn.cursor()
    
    # Get last 7 days
    today = datetime.now().date()
    dates = [(today - timedelta(days=i)).strftime('%Y-%m-%d') for i in range(7)]
    
    # Initialize result dictionary
    stats = {date: 0 for date in dates}
    
    # Query database for chat counts by date
    cursor.execute('''
        SELECT date(timestamp) as chat_date, COUNT(*) as count 
        FROM chat_history 
        WHERE date(timestamp) >= date('now', '-7 days')
        GROUP BY date(timestamp) 
    ''')
    
    for row in cursor.fetchall():
        if row[0] in stats:
            stats[row[0]] = row[1]
    
    conn.close()
    
    # Convert to lists for chart.js
    labels = list(stats.keys())
    data = list(stats.values())
    
    return labels, data
