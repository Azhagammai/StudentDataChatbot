import sqlite3
import datetime

class User:
    def __init__(self, id, serial_no, roll_no, name, user_type='student', last_login=None):
        self.id = id
        self.serial_no = serial_no
        self.roll_no = roll_no
        self.name = name
        self.user_type = user_type
        self.last_login = last_login or datetime.datetime.now()
    
    @classmethod
    def get_by_credentials(cls, serial_no, roll_no):
        conn = sqlite3.connect('student_chatbot.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE serial_no = ? AND roll_no = ?', 
                      (serial_no, roll_no))
        user_data = cursor.fetchone()
        conn.close()
        
        if user_data:
            return cls(
                id=user_data['id'],
                serial_no=user_data['serial_no'],
                roll_no=user_data['roll_no'],
                name=user_data['name'],
                user_type=user_data['user_type'],
                last_login=user_data['last_login']
            )
        return None
    
    @classmethod
    def get_by_id(cls, user_id):
        conn = sqlite3.connect('student_chatbot.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM users WHERE id = ?', (user_id,))
        user_data = cursor.fetchone()
        conn.close()
        
        if user_data:
            return cls(
                id=user_data['id'],
                serial_no=user_data['serial_no'],
                roll_no=user_data['roll_no'],
                name=user_data['name'],
                user_type=user_data['user_type'],
                last_login=user_data['last_login']
            )
        return None

class ChatHistory:
    def __init__(self, id, user_id, question, answer, timestamp=None):
        self.id = id
        self.user_id = user_id
        self.question = question
        self.answer = answer
        self.timestamp = timestamp or datetime.datetime.now()
    
    @classmethod
    def save(cls, user_id, question, answer):
        conn = sqlite3.connect('student_chatbot.db')
        cursor = conn.cursor()
        
        timestamp = datetime.datetime.now()
        cursor.execute(
            'INSERT INTO chat_history (user_id, question, answer, timestamp) VALUES (?, ?, ?, ?)',
            (user_id, question, answer, timestamp)
        )
        
        chat_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return cls(
            id=chat_id,
            user_id=user_id,
            question=question,
            answer=answer,
            timestamp=timestamp
        )
    
    @classmethod
    def get_user_history(cls, user_id):
        conn = sqlite3.connect('student_chatbot.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM chat_history WHERE user_id = ? ORDER BY timestamp',
            (user_id,)
        )
        
        history = []
        for row in cursor.fetchall():
            history.append(cls(
                id=row['id'],
                user_id=row['user_id'],
                question=row['question'],
                answer=row['answer'],
                timestamp=row['timestamp']
            ))
        
        conn.close()
        return history

class Document:
    def __init__(self, id, filename, file_path, upload_date=None, description=''):
        self.id = id
        self.filename = filename
        self.file_path = file_path
        self.upload_date = upload_date or datetime.datetime.now()
        self.description = description
    
    @classmethod
    def save(cls, filename, file_path, description=''):
        conn = sqlite3.connect('student_chatbot.db')
        cursor = conn.cursor()
        
        upload_date = datetime.datetime.now()
        cursor.execute(
            'INSERT INTO documents (filename, file_path, upload_date, description) VALUES (?, ?, ?, ?)',
            (filename, file_path, upload_date, description)
        )
        
        doc_id = cursor.lastrowid
        conn.commit()
        conn.close()
        
        return cls(
            id=doc_id,
            filename=filename,
            file_path=file_path,
            upload_date=upload_date,
            description=description
        )
    
    @classmethod
    def get_all(cls):
        conn = sqlite3.connect('student_chatbot.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM documents ORDER BY upload_date DESC')
        
        documents = []
        for row in cursor.fetchall():
            documents.append(cls(
                id=row['id'],
                filename=row['filename'],
                file_path=row['file_path'],
                upload_date=row['upload_date'],
                description=row['description']
            ))
        
        conn.close()
        return documents
