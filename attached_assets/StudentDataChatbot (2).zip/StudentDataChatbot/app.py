import os
import re
import logging
import pandas as pd
import sqlite3
import google.generativeai as genai
from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
import datetime
import json
from utils import extract_pdf_text, get_student_data, validate_student, format_gemini_response
import config

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get("SESSION_SECRET", "your_fallback_secret_key")
app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)

# Configure Gemini API
try:
    genai.configure(api_key=config.GEMINI_API_KEY)
    logger.info("Successfully configured Gemini API")
except Exception as e:
    logger.error(f"Error configuring Gemini API: {str(e)}")

# Create SQLite database and tables if they don't exist
def init_db():
    conn = sqlite3.connect('student_chatbot.db')
    cursor = conn.cursor()
    
    # Create users table for student authentication
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            serial_no INTEGER,
            roll_no INTEGER,
            name TEXT,
            user_type TEXT DEFAULT 'student',
            last_login TIMESTAMP
        )
    ''')
    
    # Create chat_history table
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS chat_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            question TEXT,
            answer TEXT,
            timestamp TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users (id)
        )
    ''')
    
    # Create admin user if not exists
    cursor.execute('SELECT * FROM users WHERE user_type = "admin"')
    if not cursor.fetchone():
        cursor.execute('INSERT INTO users (serial_no, roll_no, name, user_type) VALUES (?, ?, ?, ?)',
                      (0, 0, 'Administrator', 'admin'))
    
    # Create documents table for reference materials
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS documents (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            filename TEXT,
            file_path TEXT,
            upload_date TIMESTAMP,
            description TEXT
        )
    ''')
    
    conn.commit()
    conn.close()

# Function to generate responses using Gemini API
def generate_response_with_gemini(context, question):
    """Generate a response using the Gemini API with fallback options.
    
    If API fails, will use direct pattern matching for common student questions.
    """
    # First try to extract student data from context if available
    student_data = extract_student_data_from_context(context)
    
    # Check if it's a common question that can be answered directly without API
    # This allows the system to function even when API isn't available
    direct_response = get_direct_response(question, student_data)
    if direct_response:
        logger.info("Using direct response pattern matching")
        return direct_response
    
    try:
        logger.info("Attempting to use Gemini API...")
        
        # Create a generation config
        gen_config = {
            "temperature": 0.7,
            "top_p": 0.95,
            "top_k": 40,
            "max_output_tokens": 2048,
        }
        
        # Safety settings
        safety_settings = [
            {
                "category": "HARM_CATEGORY_HARASSMENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_HATE_SPEECH",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_SEXUALLY_EXPLICIT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            },
            {
                "category": "HARM_CATEGORY_DANGEROUS_CONTENT",
                "threshold": "BLOCK_MEDIUM_AND_ABOVE"
            }
        ]
        
        # Try different models - fallback mechanism
        model = None
        for model_name in ["gemini-1.5-pro", "gemini-1.0-pro", "gemini-pro"]:
            try:
                logger.info(f"Trying model: {model_name}")
                model = genai.GenerativeModel(
                    model_name=model_name, 
                    generation_config=gen_config,
                    safety_settings=safety_settings
                )
                break
            except Exception as model_error:
                logger.warning(f"Model {model_name} not available: {str(model_error)}")
        
        if model is None:
            logger.error("All Gemini models failed to initialize")
            # Fallback to direct pattern matching with informative message
            return get_fallback_response(question, student_data)
        
        # Start chat session and send message
        chat = model.start_chat(history=[])
        prompt = f"{context}\n\nStudent question: {question}"
        logger.info(f"Sending prompt to Gemini API: {prompt[:100]}...")
        
        response = chat.send_message(prompt)
        logger.info("Successfully received response from Gemini API")
        
        return response.text
    
    except Exception as e:
        logger.error(f"Error generating response with Gemini: {str(e)}")
        
        # Fallback to direct pattern matching with informative message
        return get_fallback_response(question, student_data)

def extract_student_data_from_context(context):
    """Extract student data from the context if available."""
    student_data = {}
    try:
        # Add debug logging
        logger.info(f"Extracting student data from context (length: {len(context)})")
        
        # Extract student info section from prompt context
        student_info_match = re.search(r'information about the student.*?(?=Here\'s information about the college|When answering)', context, re.DOTALL | re.IGNORECASE)
        if student_info_match:
            student_info_section = student_info_match.group(0)
            logger.info(f"Found student info section with length: {len(student_info_section)}")
        else:
            student_info_section = context
            logger.info("Could not find specific student section, using entire context")
        
        # Look for common patterns in the context to extract student data
        lines = student_info_section.split('\n')
        for line in lines:
            line = line.strip()
            if ':' in line:
                key, value = line.split(':', 1)
                key = key.strip()
                value = value.strip()
                if key and value:
                    # Remove any extra quotation marks
                    if value.startswith('"') and value.endswith('"'):
                        value = value[1:-1]
                    student_data[key] = value
                    logger.info(f"Extracted student data: {key} = {value}")
        
        # Direct extraction of CGPA for reliability
        cgpa_match = re.search(r'current_gpa.*?["\s]*([0-9.]+)["\s]*', context, re.IGNORECASE)
        if cgpa_match:
            student_data['current_gpa'] = cgpa_match.group(1)
            logger.info(f"Directly extracted CGPA: {student_data['current_gpa']}")
        
        # Look for all semester data
        for i in range(1, 7):
            sem_match = re.search(f'Semester {i}.*?["\s]*([0-9.]+)["\s]*', context, re.IGNORECASE)
            if sem_match:
                student_data[f'Semester {i}'] = sem_match.group(1)
                logger.info(f"Directly extracted Semester {i}: {student_data[f'Semester {i}']}")
        
        # If still empty, fall back to a more aggressive extraction
        if not student_data:
            logger.warning("No data extracted using standard method, trying aggressive pattern matching")
            
            # Look for name
            name_match = re.search(r'[Nn]ame:?\s*([A-Za-z\s]+)', context)
            if name_match:
                student_data['name'] = name_match.group(1).strip()
            
            # Look for roll number
            roll_match = re.search(r'[Rr]oll\s*[Nn]umber:?\s*(\d+)', context)
            if roll_match:
                student_data['roll_no'] = roll_match.group(1).strip()
            
            # Look for CGPA
            cgpa_match = re.search(r'[Cc][Gg][Pp][Aa]:?\s*(\d+\.\d+)', context)
            if cgpa_match:
                student_data['current_gpa'] = cgpa_match.group(1).strip()
            
            # Look for attendance
            present_match = re.search(r'[Dd]ays\s*[Pp]resent:?\s*(\d+)', context)
            if present_match:
                student_data['days_present'] = present_match.group(1).strip()
                
            total_match = re.search(r'[Tt]otal\s*[Dd]ays:?\s*(\d+)', context)
            if total_match:
                student_data['total_days'] = total_match.group(1).strip()
        
        logger.info(f"Extracted {len(student_data)} student data fields: {list(student_data.keys())}")
        return student_data
    except Exception as e:
        logger.error(f"Error extracting student data from context: {str(e)}")
        return {}

def get_direct_response(question, student_data):
    """Get direct responses for common questions without using API."""
    if not student_data:
        logger.warning("No student data available for direct response")
    else:
        logger.info(f"Attempting direct response with {len(student_data)} data fields")
        
        # Debug log for development
        logger.debug(f"Available student data keys: {sorted(list(student_data.keys()))}")
    
    question_lower = question.lower().strip()
    logger.info(f"Processing question: '{question_lower}'")
    
    # Parent information questions
    if any(term in question_lower for term in ["parent", "father", "mother", "dad", "mom", "family"]):
        logger.info("Detected parent information question")
        
        # Try to find father's name
        father_name = None
        for key in ["father_name", "Father's Name", "Father Name", "Dad", "dad", "father"]:
            if student_data.get(key):
                father_name = student_data.get(key)
                logger.info(f"Found father's name: {father_name}")
                break
        
        # Try to find mother's name
        mother_name = None
        for key in ["mother_name", "Mother's Name", "Mother Name", "Mom", "mom", "mother"]:
            if student_data.get(key):
                mother_name = student_data.get(key)
                logger.info(f"Found mother's name: {mother_name}")
                break
        
        if father_name or mother_name:
            parent_details = "Here are your parent details:\n\n"
            if father_name:
                parent_details += f"Father's Name: {father_name}\n"
            if mother_name:
                parent_details += f"Mother's Name: {mother_name}\n"
                
            # Try to get additional parent info if available
            for key in student_data:
                if "parent" in key.lower() or "guardian" in key.lower():
                    if key.lower() not in ["father_name", "mother_name"]:
                        parent_details += f"{key}: {student_data.get(key)}\n"
            
            return parent_details
        else:
            return "I don't have information about your parents in my records. Please contact the academic office to update your family details."
    
    # Contact information
    if any(term in question_lower for term in ["contact", "phone", "number", "mobile", "telephone", "email", "address"]):
        logger.info("Detected contact information question")
        
        # Try to find phone number
        phone = None
        for key in ["phone_number", "Phone Number", "mobile", "Mobile", "contact", "Contact"]:
            if student_data.get(key):
                phone = student_data.get(key)
                logger.info(f"Found phone number: {phone}")
                break
        
        # Try to find address components
        address_components = []
        for key in ["street", "city", "state", "pin_code", "pincode", "zip", "address"]:
            if student_data.get(key):
                address_components.append(f"{key.replace('_', ' ').title()}: {student_data.get(key)}")
                logger.info(f"Found address component: {key}")
        
        if phone or address_components:
            contact_info = "Here is your contact information:\n\n"
            if phone:
                contact_info += f"Phone Number: {phone}\n"
            
            if address_components:
                contact_info += "\nAddress:\n" + "\n".join(address_components)
                
            return contact_info
        else:
            return "I don't have your contact information in my records. Please visit the academic office to update your contact details."
    
    # CGPA related questions
    if any(q in question_lower for q in ["what is my cgpa", "my cgpa", "current gpa", "what's my gpa", "gpa"]):
        logger.info("Detected CGPA question")
        cgpa = None
        
        # Try multiple possible keys for CGPA
        for key in ["current_gpa", "Current GPA", "CGPA", "cgpa", "GPA", "gpa"]:
            if student_data.get(key):
                cgpa = student_data.get(key)
                break
        
        if cgpa:
            logger.info(f"Found CGPA value: {cgpa}")
            return f"Your current CGPA is {cgpa}."
        else:
            # If we know this is a CGPA question but data is missing, give appropriate response
            logger.warning("CGPA question detected but no CGPA data found")
            return "I can see you're asking about your CGPA, but I don't have that information in my records. Please contact the academic office for this information."
    
    # Student details - more broadly match detail requests
    if any(q in question_lower for q in ["detail", "information", "about me", "my info", "who am i", "give my"]):
        logger.info("Detected student details question")
        
        # Try to get the name first
        name = None
        for key in ["name", "Name", "Student Name", "STUDENT NAME", "student_name"]:
            if student_data.get(key):
                name = student_data.get(key)
                break
        
        if name:
            logger.info(f"Found student name: {name}")
            
            # Get other core details with fallbacks
            roll_no = None
            for key in ["roll_no", "Roll Number", "roll number", "Roll No"]:
                if student_data.get(key):
                    roll_no = student_data.get(key)
                    break
                    
            major = None
            for key in ["major", "Major", "MAJOR", "department", "Department"]:
                if student_data.get(key):
                    major = student_data.get(key)
                    break
            
            # Build a comprehensive student profile
            details = f"Here are your details:\n\n"
            details += f"Name: {name}\n"
            if roll_no: details += f"Roll Number: {roll_no}\n"
            if major: details += f"Major: {major}\n"
            
            # Add other important fields with better labels
            field_mapping = {
                "gender": "Gender",
                "date_of_birth": "Date of Birth",
                "current_gpa": "CGPA",
                "phone_number": "Phone Number",
                "father_name": "Father's Name",
                "mother_name": "Mother's Name",
                "street": "Street Address",
                "city": "City",
                "state": "State",
                "pin_code": "PIN Code",
                "hobbies": "Hobbies",
                "serial_no": "Serial Number"
            }
            
            # Add mapped fields with proper labels
            for field, label in field_mapping.items():
                if student_data.get(field):
                    details += f"{label}: {student_data.get(field)}\n"
            
            # Add semester GPA information
            details += "\nSemester GPA:\n"
            has_semester_data = False
            for i in range(1, 7):
                sem_key = f"Semester {i}"
                if student_data.get(sem_key):
                    details += f"{sem_key}: {student_data.get(sem_key)}\n"
                    has_semester_data = True
            
            if not has_semester_data:
                details += "No semester data available\n"
                
            # Add attendance information
            days_present = student_data.get("days_present")
            total_days = student_data.get("total_days")
            if days_present and total_days:
                try:
                    attendance = (float(days_present) / float(total_days)) * 100
                    details += f"\nAttendance: {attendance:.2f}% ({days_present}/{total_days} days)\n"
                except:
                    pass
                    
            # Add course information
            courses = student_data.get("courses")
            if courses:
                details += f"\nEnrolled Courses: {courses}\n"
            
            line_count = details.count('\n')
            logger.info(f"Returning {line_count} lines of student details")
            return details
        else:
            # If name not found but we have some data, return what we have
            if len(student_data) > 0:
                details = "Here are the details I have on record:\n\n"
                for key, value in student_data.items():
                    if key not in ["Semester 1", "Semester 2", "Semester 3", "Semester 4", "Semester 5", "Semester 6"]:
                        details += f"{key}: {value}\n"
                return details
            else:
                logger.warning("Student details question detected but no data found")
                return "I don't have your student details in my records. Please contact the academic office for assistance."
    
    # Attendance related questions
    if any(q in question_lower for q in ["attendance", "classes", "present", "absent", "how many day"]):
        logger.info("Detected attendance question")
        
        # Find days present and total days
        days_present = None
        for key in ["days_present", "Days Present", "Present", "present", "PRESENT"]:
            if student_data.get(key):
                days_present = student_data.get(key)
                break
                
        total_days = None
        for key in ["total_days", "Total Days", "total", "TOTAL DAYS"]:
            if student_data.get(key):
                total_days = student_data.get(key)
                break
        
        if days_present and total_days:
            try:
                logger.info(f"Calculating attendance with days_present={days_present}, total_days={total_days}")
                attendance_percentage = (float(days_present) / float(total_days)) * 100
                return f"Your attendance is {attendance_percentage:.2f}% ({days_present} days present out of {total_days} total days).\n\nAccording to college policy, you need to maintain at least 75% attendance to be eligible for final examinations."
            except Exception as e:
                logger.error(f"Error calculating attendance: {str(e)}")
        else:
            logger.warning("Attendance question detected but missing days_present or total_days")
            return "I can see you're asking about your attendance, but I don't have complete attendance records available."
    
    # Grades/Semester results - broaden the match
    if any(q in question_lower for q in ["grades", "semester", "results", "performance", "marks"]):
        logger.info("Detected grades/semester results question")
        grades_info = "Here are your semester grades:\n\n"
        has_grades = False
        
        for i in range(1, 7):
            sem_key = f"Semester {i}"
            sem_value = student_data.get(sem_key)
            if sem_value:
                grades_info += f"{sem_key}: {sem_value}\n"
                has_grades = True
        
        if has_grades:
            # Add CGPA information
            cgpa = None
            for key in ["current_gpa", "Current GPA", "CGPA", "cgpa"]:
                if student_data.get(key):
                    cgpa = student_data.get(key)
                    break
                    
            if cgpa:
                grades_info += f"\nCurrent CGPA: {cgpa}\n"
                
            logger.info(f"Found grades for {has_grades} semesters")
            return grades_info
        else:
            logger.warning("Grades question detected but no semester data found")
            return "I can see you're asking about your grades, but I don't have semester-wise grade information in my records."
    
    # Courses
    if any(q in question_lower for q in ["courses", "subjects", "studying", "enrolled", "classes", "learning"]):
        logger.info("Detected courses question")
        
        courses = None
        for key in ["courses", "Courses", "subjects", "Subjects", "COURSES"]:
            if student_data.get(key):
                courses = student_data.get(key)
                break
                
        if courses:
            logger.info(f"Found courses: {courses}")
            return f"You are enrolled in the following courses: {courses}\n\nEach course requires a minimum of 75% attendance to be eligible for the final examination."
        else:
            logger.warning("Courses question detected but no courses data found")
            return "I can see you're asking about your courses, but I don't have that information in my records."
    
    # Personal information (DOB, gender, etc.)
    if any(term in question_lower for term in ["birth", "dob", "age", "gender", "sex", "personal", "hobbies", "hobby"]):
        logger.info("Detected personal information question")
        
        personal_info = "Here is your personal information:\n\n"
        has_personal_info = False
        
        # Map of fields to look for and their display names
        fields = {
            "date_of_birth": "Date of Birth",
            "gender": "Gender",
            "hobbies": "Hobbies"
        }
        
        for field, display_name in fields.items():
            for key in [field, display_name, field.replace('_', ' ').title()]:
                if student_data.get(key):
                    personal_info += f"{display_name}: {student_data.get(key)}\n"
                    has_personal_info = True
                    break
        
        if has_personal_info:
            return personal_info
        else:
            return "I don't have personal information like your date of birth, gender, or hobbies in my records."
    
    logger.info("No direct match found for question pattern")
    return None

def get_fallback_response(question, student_data):
    """Generate a fallback response when API is not available."""
    # First try direct pattern matching
    direct_response = get_direct_response(question, student_data)
    if direct_response:
        return direct_response
    
    question_lower = question.lower()
    logger.info(f"Looking for fallback response for: '{question_lower}'")
    
    # Generic responses based on question topic
    if any(word in question_lower for word in ["hello", "hi ", "hey", "greetings"]):
        name = student_data.get("name") or student_data.get("Name") or "there"
        return f"Hello {name}! I'm your student assistant. How can I help you today?"
    
    if any(word in question_lower for word in ["bye", "goodbye", "see you", "exit"]):
        return "Goodbye! Feel free to come back if you have more questions."
    
    if any(word in question_lower for word in ["thank", "thanks", "appreciate"]):
        return "You're welcome! I'm happy to help with any other questions you might have."
    
    # Code of Conduct related questions - use the improved PDF search functionality
    if any(term in question_lower for term in ["code of conduct", "rules", "policy", "guidelines", "handbook", 
                                             "regulations", "prohibited", "allowed", "disciplinary", "violation",
                                             "punishment", "penalty", "offense"]):
        logger.info("Detected code of conduct question, searching PDF content")
        
        # Use the new search functionality from utils
        from utils import search_pdf_content
        
        # Try to find all available PDFs
        pdf_paths = []
        for path in ['data/code_of_conduct.pdf', 'attached_assets/code_of_conduct.pdf']:
            import os
            if os.path.exists(path):
                pdf_paths.append(path)
                
        # Also look in uploads directory if it exists
        import os
        if os.path.exists('uploads'):
            for filename in os.listdir('uploads'):
                if filename.endswith('.pdf'):
                    pdf_paths.append(os.path.join('uploads', filename))
        
        if pdf_paths:
            logger.info(f"Found {len(pdf_paths)} PDFs to search: {pdf_paths}")
            
            # Search through all PDFs for the best result
            best_result = None
            for pdf_path in pdf_paths:
                # Search for content related to the question
                search_result = search_pdf_content(question, pdf_path=pdf_path)
                
                if search_result and not search_result.startswith("No specific information"):
                    logger.info(f"Found relevant content in PDF {pdf_path} for question: {question}")
                    
                    # Keep the best (longest) result
                    if best_result is None or len(search_result) > len(best_result):
                        best_result = search_result
            
            if best_result:
                # Format the response for better readability
                formatted_result = "Based on the Code of Conduct:\n\n" + best_result
                
                # If it's too long, truncate it
                if len(formatted_result) > 1000:
                    formatted_result = formatted_result[:997] + "..."
                
                return formatted_result
        
        # More specific policy questions that weren't directly found in the PDF
        
        # Attendance policy
        if any(term in question_lower for term in ["attendance policy", "attendance requirement", "minimum attendance"]):
            return "Based on the college's Code of Conduct, students are required to maintain at least 75% attendance in all courses. Failure to meet this requirement may result in ineligibility to sit for final examinations. Medical emergencies require proper documentation and approval from the department head. Attendance is taken at the beginning of each class, and being late by more than 10 minutes may be counted as an absence."
        
        # Academic integrity
        if any(term in question_lower for term in ["academic integrity", "plagiarism", "cheating", "copying"]):
            return "According to the Code of Conduct, academic integrity violations are taken very seriously. Plagiarism (using others' work without proper citation), cheating during examinations, falsifying data, and unauthorized collaboration are all considered violations. Penalties range from a zero on the assignment to course failure, academic probation, or even expulsion in severe cases. All suspected cases are reviewed by the Academic Integrity Board."
        
        # Dress code
        if any(term in question_lower for term in ["dress code", "uniform", "attire", "clothing"]):
            return "The college's dress code policy requires students to dress in a manner appropriate for an academic environment. Professional attire is recommended. Specifically prohibited items include: clothing with offensive graphics or slogans, excessively revealing attire, torn jeans, flip-flops (except in residential areas), and visible undergarments. Engineering and science laboratories have additional safety requirements including closed-toe shoes and appropriate protective equipment."
        
        # General disciplinary procedures
        if any(term in question_lower for term in ["disciplinary", "violation", "punishment", "penalty"]):
            return "The college's disciplinary procedure follows a tiered approach based on the severity and frequency of violations. First-time minor violations typically result in a warning. Repeated or more serious violations may lead to probation, community service, or loss of privileges. Severe violations can result in suspension or expulsion. All students have the right to a fair hearing before the Disciplinary Committee, and appeals must be filed within 7 days of a decision."
        
        # Fallback generic response about code of conduct
        return "The college has a comprehensive code of conduct that covers academic integrity, campus behavior, and disciplinary procedures. It includes rules about attendance (minimum 75% required), academic honesty (plagiarism and cheating penalties), campus behavior (respectful conduct in classrooms and common areas), dress code (professional attire), and use of college facilities. For specific details, please ask about a particular policy area such as 'What is the attendance policy?' or 'What are the rules about academic integrity?'"
    
    # Academic policies
    if any(term in question_lower for term in ["attendance policy", "attendance rule", "minimum attendance", "absent", "required attendance"]):
        return "According to the college attendance policy, students are required to maintain at least 75% attendance in each course. If you miss more than 25% of classes, you may not be allowed to sit for final examinations. Medical emergencies require proper documentation for consideration."
    
    if any(term in question_lower for term in ["academic integrity", "plagiarism", "cheating", "copying", "academic dishonesty"]):
        return "The college has a strict academic integrity policy. Plagiarism, cheating in exams, falsifying data, and other forms of academic dishonesty can result in penalties ranging from a zero on the assignment to course failure or even expulsion in severe cases. Always submit your own work and properly cite all sources."
    
    if any(term in question_lower for term in ["dress code", "uniform", "attire", "what to wear"]):
        return "The college requires students to dress appropriately and professionally. Business casual attire is recommended. T-shirts with offensive slogans, revealing clothing, and torn jeans are not permitted. Specific departments may have additional dress requirements for laboratory or workshop sessions."
    
    # Default fallback for when we can't determine intent
    return "I'm currently experiencing some technical limitations. Please try asking a specific question about your academic records, like 'What is my CGPA?' or 'What are my semester grades?' You can also ask about college policies such as 'What is the attendance policy?' or 'Tell me about the code of conduct.'"

# Initialize database
init_db()

# Load code of conduct text
try:
    logger.info("Loading code of conduct text...")
    # Try various possible locations
    for path in ['data/code_of_conduct.pdf', 'attached_assets/code_of_conduct.pdf']:
        import os
        if os.path.exists(path):
            logger.info(f"Found code of conduct at: {path}")
            code_of_conduct_text = extract_pdf_text(path)
            if code_of_conduct_text and not code_of_conduct_text.startswith("Error"):
                logger.info(f"Successfully loaded code of conduct with {len(code_of_conduct_text)} characters")
                break
    else:
        logger.warning("Could not find code of conduct PDF, using placeholder text")
        code_of_conduct_text = "Code of conduct text not available. Please contact administrator."
except Exception as e:
    logger.error(f"Error loading code of conduct: {str(e)}")
    code_of_conduct_text = "Error loading code of conduct."

# Routes
@app.route('/')
def index():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        serial_no = request.form.get('serial_no')
        roll_no = request.form.get('roll_no')
        
        if not serial_no or not roll_no:
            error = "Please enter both serial number and roll number"
        else:
            # Validate student credentials
            student = validate_student(serial_no, roll_no)
            if student:
                # Check if user already exists in database
                conn = sqlite3.connect('student_chatbot.db')
                cursor = conn.cursor()
                cursor.execute('SELECT id FROM users WHERE serial_no = ? AND roll_no = ?', 
                              (serial_no, roll_no))
                user = cursor.fetchone()
                
                if not user:
                    # Add new user
                    cursor.execute('INSERT INTO users (serial_no, roll_no, name, last_login) VALUES (?, ?, ?, ?)',
                                  (serial_no, roll_no, student['name'], datetime.datetime.now()))
                    conn.commit()
                    cursor.execute('SELECT id FROM users WHERE serial_no = ? AND roll_no = ?', 
                                 (serial_no, roll_no))
                    user = cursor.fetchone()
                else:
                    # Update last login time
                    cursor.execute('UPDATE users SET last_login = ? WHERE id = ?',
                                 (datetime.datetime.now(), user[0]))
                    conn.commit()
                
                conn.close()
                
                # Set session variables
                session['user_id'] = user[0]
                session['serial_no'] = serial_no
                session['roll_no'] = roll_no
                session['name'] = student['name']
                session['user_type'] = 'student'
                
                return redirect(url_for('chat'))
            else:
                error = "Invalid serial number or roll number. Please try again."
    
    return render_template('login.html', error=error)

@app.route('/admin', methods=['GET', 'POST'])
def admin_login():
    error = None
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        # Simple admin authentication (in production, use proper authentication)
        if username == 'admin' and password == 'admin123':
            conn = sqlite3.connect('student_chatbot.db')
            cursor = conn.cursor()
            cursor.execute('SELECT id FROM users WHERE user_type = "admin"')
            admin = cursor.fetchone()
            conn.close()
            
            session['user_id'] = admin[0]
            session['user_type'] = 'admin'
            session['name'] = 'Administrator'
            
            return redirect(url_for('admin_dashboard'))
        else:
            error = "Invalid credentials. Please try again."
    
    return render_template('admin_login.html', error=error)

@app.route('/admin/dashboard')
def admin_dashboard():
    if session.get('user_type') != 'admin':
        return redirect(url_for('admin_login'))
    
    # Get statistics for dashboard
    conn = sqlite3.connect('student_chatbot.db')
    cursor = conn.cursor()
    
    # Count total students
    cursor.execute('SELECT COUNT(*) FROM users WHERE user_type = "student"')
    total_students = cursor.fetchone()[0]
    
    # Count total conversations
    cursor.execute('SELECT COUNT(*) FROM chat_history')
    total_conversations = cursor.fetchone()[0]
    
    # Get recent chats
    cursor.execute('''
        SELECT u.name, c.question, c.answer, c.timestamp 
        FROM chat_history c 
        JOIN users u ON c.user_id = u.id 
        ORDER BY c.timestamp DESC LIMIT 10
    ''')
    recent_chats = cursor.fetchall()
    
    # Get documents
    cursor.execute('SELECT id, filename, upload_date, description FROM documents ORDER BY upload_date DESC')
    documents = cursor.fetchall()
    
    # Get chat statistics by day (for chart)
    cursor.execute('''
        SELECT date(timestamp) as chat_date, COUNT(*) as count 
        FROM chat_history 
        GROUP BY date(timestamp) 
        ORDER BY chat_date DESC LIMIT 7
    ''')
    chat_stats = cursor.fetchall()
    
    # Format for chart.js
    dates = [row[0] for row in chat_stats]
    counts = [row[1] for row in chat_stats]
    
    conn.close()
    
    return render_template('admin_dashboard.html', 
                          total_students=total_students,
                          total_conversations=total_conversations,
                          recent_chats=recent_chats,
                          documents=documents,
                          chat_dates=json.dumps(dates),
                          chat_counts=json.dumps(counts))

@app.route('/admin/add_student', methods=['POST'])
def add_student():
    if session.get('user_type') != 'admin':
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    
    try:
        # Get form data
        data = request.form
        serial_no = data.get('serial_no')
        roll_no = data.get('roll_no')
        name = data.get('name')
        
        # Basic validation
        if not serial_no or not roll_no or not name:
            return jsonify({'success': False, 'error': 'All required fields must be filled'}), 400
        
        # Check if student already exists
        conn = sqlite3.connect('student_chatbot.db')
        cursor = conn.cursor()
        cursor.execute('SELECT id FROM users WHERE serial_no = ? AND roll_no = ?', 
                      (serial_no, roll_no))
        existing_user = cursor.fetchone()
        
        if existing_user:
            conn.close()
            return jsonify({'success': False, 'error': 'Student already exists'}), 400
        
        # Add to database
        cursor.execute('INSERT INTO users (serial_no, roll_no, name, user_type, last_login) VALUES (?, ?, ?, ?, ?)',
                      (serial_no, roll_no, name, 'student', datetime.datetime.now()))
        conn.commit()
        conn.close()
        
        # Get all form fields with defaults if not provided
        street = data.get('street', 'N/A')
        city = data.get('city', 'N/A')
        state = data.get('state', 'N/A')
        pin_code = data.get('pin_code', '00000')
        father_name = data.get('father_name', 'N/A')
        mother_name = data.get('mother_name', 'N/A')
        phone_number = data.get('phone_number', 'N/A')
        
        # Convert numeric fields with appropriate defaults
        try:
            total_days = int(data.get('total_days', 180))
        except (ValueError, TypeError):
            total_days = 180
            
        try:
            days_present = int(data.get('days_present', 0))
        except (ValueError, TypeError):
            days_present = 0
            
        try:
            days_absent = int(data.get('days_absent', 0))
        except (ValueError, TypeError):
            days_absent = 0
            
        major = data.get('major', 'N/A')
        
        try:
            current_gpa = float(data.get('current_gpa', 0.0))
        except (ValueError, TypeError):
            current_gpa = 0.0
            
        courses = data.get('courses', 'N/A')
        date_of_birth = data.get('date_of_birth', '2000-01-01')
        gender = data.get('gender', 'N/A')
        hobbies = data.get('hobbies', 'N/A')
        
        # Get semester GPAs
        try:
            sem1 = float(data.get('semester1', 0.0))
        except (ValueError, TypeError):
            sem1 = 0.0
            
        try:
            sem2 = float(data.get('semester2', 0.0))
        except (ValueError, TypeError):
            sem2 = 0.0
            
        try:
            sem3 = float(data.get('semester3', 0.0))
        except (ValueError, TypeError):
            sem3 = 0.0
            
        try:
            sem4 = float(data.get('semester4', 0.0))
        except (ValueError, TypeError):
            sem4 = 0.0
            
        try:
            sem5 = float(data.get('semester5', 0.0))
        except (ValueError, TypeError):
            sem5 = 0.0
            
        try:
            sem6 = float(data.get('semester6', 0.0))
        except (ValueError, TypeError):
            sem6 = 0.0
        
        # Update CSV file
        try:
            # Read existing CSV
            df = pd.read_csv('data/students.csv')
            
            # Create new row with all captured data
            new_row = pd.DataFrame({
                'serial_no': [serial_no],
                'roll_no': [roll_no],
                'name': [name],
                'street': [street],
                'city': [city],
                'state': [state],
                'pin_code': [pin_code],
                'father_name': [father_name],
                'mother_name': [mother_name],
                'phone_number': [phone_number],
                'total_days': [total_days],
                'days_present': [days_present],
                'days_absent': [days_absent],
                'major': [major],
                'current_gpa': [current_gpa],
                'courses': [courses],
                'date_of_birth': [date_of_birth],
                'gender': [gender],
                'hobbies': [hobbies],
                'Semester 1': [sem1],
                'Semester 2': [sem2],
                'Semester 3': [sem3],
                'Semester 4': [sem4],
                'Semester 5': [sem5],
                'Semester 6': [sem6]
            })
            
            # Append to dataframe and save
            df = pd.concat([df, new_row], ignore_index=True)
            
            # Save to both original and updated CSV files to ensure consistency
            df.to_csv('data/students.csv', index=False)
            df.to_csv('data/updated_students_data.csv', index=False)
        except Exception as e:
            logger.error(f"Error updating CSV: {str(e)}")
            # Continue anyway since the user is added to the database
        
        return jsonify({'success': True, 'message': 'Student added successfully'})
    
    except Exception as e:
        logger.error(f"Error adding student: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/admin/upload_document', methods=['POST'])
def upload_document():
    if session.get('user_type') != 'admin':
        return jsonify({'success': False, 'error': 'Unauthorized'}), 401
    
    if 'document' not in request.files:
        return jsonify({'success': False, 'error': 'No file uploaded'}), 400
    
    file = request.files['document']
    description = request.form.get('description', '')
    
    if file.filename == '':
        return jsonify({'success': False, 'error': 'No file selected'}), 400
    
    if file:
        filename = secure_filename(file.filename)
        file_path = os.path.join('data', filename)
        file.save(file_path)
        
        conn = sqlite3.connect('student_chatbot.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO documents (filename, file_path, upload_date, description) VALUES (?, ?, ?, ?)',
                     (filename, file_path, datetime.datetime.now(), description))
        conn.commit()
        conn.close()
        
        return jsonify({'success': True, 'message': 'Document uploaded successfully'})
    
    return jsonify({'success': False, 'error': 'Failed to upload file'}), 500

@app.route('/chat')
def chat():
    if 'user_id' not in session or session.get('user_type') != 'student':
        return redirect(url_for('login'))
    
    # Get student's chat history
    conn = sqlite3.connect('student_chatbot.db')
    cursor = conn.cursor()
    cursor.execute('SELECT question, answer, timestamp FROM chat_history WHERE user_id = ? ORDER BY timestamp',
                  (session['user_id'],))
    chat_history = cursor.fetchall()
    conn.close()
    
    return render_template('chat.html', 
                          name=session.get('name', 'Student'),
                          chat_history=chat_history)

@app.route('/api/chat', methods=['POST'])
def api_chat():
    if 'user_id' not in session:
        return jsonify({'error': 'Not authenticated'}), 401
    
    user_id = session['user_id']
    question = request.json.get('question', '')
    
    if not question:
        return jsonify({'error': 'No question provided'}), 400
    
    try:
        # Get student data
        if session.get('user_type') == 'student':
            try:
                student_data = get_student_data(session['serial_no'], session['roll_no'])
                logger.info(f"Retrieved student data: {student_data.keys()}")
                
                # Format student data in a clear structure
                student_info = f"""
                Student Name: {student_data.get('name', 'N/A')}
                Roll Number: {student_data.get('roll_no', 'N/A')}
                Serial Number: {student_data.get('serial_no', 'N/A')}
                Major: {student_data.get('major', 'N/A')}
                Current GPA: {student_data.get('current_gpa', 'N/A')}
                Gender: {student_data.get('gender', 'N/A')}
                Date of Birth: {student_data.get('date_of_birth', 'N/A')}
                Total Days: {student_data.get('total_days', 'N/A')}
                Days Present: {student_data.get('days_present', 'N/A')}
                Days Absent: {student_data.get('days_absent', 'N/A')}
                Attendance Percentage: {round((student_data.get('days_present', 0) / student_data.get('total_days', 1)) * 100, 2) if student_data.get('total_days', 0) > 0 else 'N/A'}%
                Courses: {student_data.get('courses', 'N/A')}
                Semester 1 GPA: {student_data.get('Semester 1', 'N/A')}
                Semester 2 GPA: {student_data.get('Semester 2', 'N/A')}
                Semester 3 GPA: {student_data.get('Semester 3', 'N/A')}
                Semester 4 GPA: {student_data.get('Semester 4', 'N/A')}
                Semester 5 GPA: {student_data.get('Semester 5', 'N/A')}
                Semester 6 GPA: {student_data.get('Semester 6', 'N/A')}
                """
                
                # Create context for Gemini with more specific instructions
                context = f"""
                You are a helpful student assistant chatbot for Dr. Mahalingam College of Engineering and Technology. 
                You help students with information about their academic records and college policies.
                
                Here's information about the student you're talking to:
                {student_info}
                
                Here's information about the college's code of conduct:
                {code_of_conduct_text[:8000]}  # Truncate to avoid token limits
                
                When answering:
                1. Only use the student data provided above - never make up information.
                2. If asked about policies, reference the code of conduct.
                3. If asked about something not in the data, politely say you don't have that information.
                4. Be helpful, concise, and friendly in your responses.
                5. Format your responses in a readable way.
                
                IMPORTANT HANDLING OF SPECIFIC QUESTIONS:
                - If the student asks "What is my CGPA?" or about their GPA, respond with their exact current_gpa value: "{student_data.get('current_gpa', 'N/A')}"
                - If asked "What are my grades?", show all semester GPAs from the data provided.
                - If asked about attendance, calculate using the formula: (days_present/total_days)*100 and show the percentage.
                - If asked "Show me my details" or "What are my personal details", organize and display the key information neatly.
                - If asked about their courses, list out the specific courses from: "{student_data.get('courses', 'N/A')}"
                
                Always use the exact data values provided above when answering specific questions about the student's information.
                """
            except Exception as data_error:
                logger.error(f"Error retrieving student data: {str(data_error)}")
                context = """
                You are a helpful student assistant chatbot for Dr. Mahalingam College of Engineering and Technology.
                There was an error retrieving student data. Please apologize to the student and ask them to try again later
                or contact the administrator for help.
                """
        else:
            # Admin context
            context = """
            You are a helpful assistant chatbot for the college administrator.
            You can help with information about the system and general queries.
            Be professional and concise in your responses.
            """
        
        # Generate response with Gemini (moved to a separate function)
        response_text = generate_response_with_gemini(context, question)
        
        # Format the response
        formatted_response = format_gemini_response(response_text)
        
        # Save to database
        conn = sqlite3.connect('student_chatbot.db')
        cursor = conn.cursor()
        cursor.execute('INSERT INTO chat_history (user_id, question, answer, timestamp) VALUES (?, ?, ?, ?)',
                      (user_id, question, formatted_response, datetime.datetime.now()))
        conn.commit()
        conn.close()
        
        return jsonify({
            'answer': formatted_response,
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
    
    except Exception as e:
        error_message = str(e)
        logger.error(f"Error generating response: {error_message}")
        
        # Create a more user-friendly error message
        if "API key" in error_message.lower():
            user_message = "Sorry, there's an issue with the API key. Please contact the administrator."
        elif "model" in error_message.lower() and "not found" in error_message.lower():
            user_message = "Sorry, the AI model is currently unavailable. Please try again later."
        elif "timeout" in error_message.lower() or "connection" in error_message.lower():
            user_message = "Sorry, there was a connection issue. Please check your internet and try again."
        else:
            user_message = "Sorry, I encountered an error while processing your request. Please try again later."
        
        # Still save the error interaction to the database for tracking
        try:
            conn = sqlite3.connect('student_chatbot.db')
            cursor = conn.cursor()
            cursor.execute('INSERT INTO chat_history (user_id, question, answer, timestamp) VALUES (?, ?, ?, ?)',
                        (user_id, question, f"ERROR: {user_message}", datetime.datetime.now()))
            conn.commit()
            conn.close()
        except:
            # If this fails too, just log and continue
            logger.error("Failed to save error to chat history")
        
        return jsonify({
            'answer': user_message,
            'timestamp': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
