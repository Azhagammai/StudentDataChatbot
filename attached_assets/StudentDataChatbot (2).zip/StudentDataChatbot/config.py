# Configuration settings
import os

# Gemini API key - get from environment variable
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY")

# Database settings
DATABASE_PATH = "student_chatbot.db"

# File paths
STUDENTS_CSV_PATH = "data/students.csv"
CODE_OF_CONDUCT_PATH = "data/code_of_conduct.pdf"

# App settings
DEBUG = True
PORT = 5000
HOST = "0.0.0.0"

# Admin credentials (for development only - in production use proper auth)
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "admin123"  # In production, use hashed passwords

# Rate limiting for Gemini API
MAX_REQUESTS_PER_MINUTE = 10
