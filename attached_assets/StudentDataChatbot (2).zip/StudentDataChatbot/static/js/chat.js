document.addEventListener('DOMContentLoaded', function() {
    const chatForm = document.getElementById('chat-form');
    const chatInput = document.getElementById('chat-input');
    const chatMessages = document.getElementById('chat-messages');
    const typingIndicator = document.getElementById('typing-indicator');
    
    // Function to add a message to the chat
    function addMessage(message, sender, timestamp) {
        const messageElement = document.createElement('div');
        messageElement.classList.add('message');
        messageElement.classList.add(sender === 'user' ? 'user-message' : 'bot-message');
        
        // Format message text with line breaks
        const formattedMessage = message.replace(/\n/g, '<br>');
        
        // Create timestamp element
        const timestampElement = document.createElement('div');
        timestampElement.classList.add('message-time');
        timestampElement.textContent = timestamp || new Date().toLocaleTimeString();
        
        // Set message content
        messageElement.innerHTML = formattedMessage;
        messageElement.appendChild(timestampElement);
        
        // Add to chat
        chatMessages.appendChild(messageElement);
        
        // Scroll to bottom
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to show typing indicator
    function showTypingIndicator() {
        typingIndicator.style.display = 'block';
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }
    
    // Function to hide typing indicator
    function hideTypingIndicator() {
        typingIndicator.style.display = 'none';
    }
    
    // Handle chat form submission
    chatForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const message = chatInput.value.trim();
        if (!message) return;
        
        // Add user message to chat
        addMessage(message, 'user');
        
        // Clear input
        chatInput.value = '';
        
        // Show typing indicator
        showTypingIndicator();
        
        // Send message to server
        fetch('/api/chat', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ question: message })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            // Hide typing indicator
            hideTypingIndicator();
            
            // Add bot message to chat
            if (data.error) {
                addMessage('Sorry, I encountered an error: ' + data.error, 'bot');
            } else {
                addMessage(data.answer, 'bot', data.timestamp);
            }
        })
        .catch(error => {
            // Hide typing indicator
            hideTypingIndicator();
            
            // Add error message
            addMessage('Sorry, I encountered an error. Please try again later.', 'bot');
            console.error('Error:', error);
        });
    });
    
    // Add event listener for Enter key
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            chatForm.dispatchEvent(new Event('submit'));
        }
    });
    
    // Focus on input when page loads
    chatInput.focus();
});
